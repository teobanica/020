N=11: an explicit three-parameter five-row family, uniformly maximal
=================================================================

Result (paper-16, Section 12.7, Theorem 12.19):
G(a,b,c) is a regular 5 x 11 matrix for all unit a,b,c and has NO
regular sixth row at any parameter value. The proof includes exceptional
tori, translated tori and their torsion components. G(1,1,1) has minimal
Butson level 60. No numerical phase samples enter the exclusion.

Scope:
The first three rows form one labelled dimension-three presentation from
DDD support class 3286. This package settles the displayed FIVE-ROW
family. It does not classify all extensions of its three-row submatrix,
all label choices of support class 3286, or all positive-dimensional DDD
families. The additional fixed rows impose essential conditions.

Requirements: Python 3 standard library; g++ with C++17 support.

Commands, from this directory:
  python3 verify.py
      Verify saved symbolic families, seed cycles, minimal seed level,
      counts, batch accounting, file integrity and recorded audit hashes.
      This is an identity/certificate check; it does not independently
      regenerate the completeness calculation.
  python3 run.py --workers 2
      Regenerate every primary/audit first-presentation batch, the fixed
      CCC core list and both complete character refinements. Work files
      are written under regenerated/, without replacing delivered data.
      Complete validated batches can be resumed. Expect substantial work.
  python3 run.py --stage refine
      Use the delivered COMPLETE fixed-core list and independently repeat
      both parameter-dependent refinements. This omits only initial core
      enumeration. Outputs again go under regenerated/.

Input and record formats:
- new_three_parameter_five.json: exponent matrix mod 60, integral powers
  of a,b,c, and ten ordered cycle covers. Rows/columns are zero-based.
- family_3286.txt: first two nonconstant rows, eleven lines per row. Each
  line is (root exponent mod 40, power of a, power of b, power of c).
- registry_origin.txt: exact original line in the predecessor component's
  families.txt. The root/power data have been compared entry by entry.
- fixed_CCC/groups.txt: one fixed three-row core. Roots stored mod 120.
  The first line is group count 1. Next: group id, number of third rows,
  eleven exponents of s. Last: third-row id, eleven exponents of t.
- fixed_CCC/pair_families.txt: profile, initial presentation index, number
  of groups, eleven group labels, eleven root exponents mod 840. Free
  phases multiply each group. 859958 normalized records, not equivalence
  classes; some families intersect. Stored in first-occurrence order.
- fixed_CCC/extensions.txt: old-third-row id, group count, eleven group
  labels, eleven exponents mod 840. 100788 records. These rows extend
  (1,s,t); all component phases are arbitrary unit scalars.
- five_compatible.txt: 118030 lines of 67 integers. First twelve: three
  Hermite rows (r_a,r_b,r_c,d), representing a^r_a b^r_b c^r_c=zeta840^d.
  A missing row is zero. Each subsequent five integers are a component
  label and (power_a,power_b,power_c,root exponent mod 840). Thus each
  entry is z_component times the stated monomial and root. Common row
  phase is immaterial. These rows extend (1,s,t,u), on the FULL stated
  parameter locus. Constraints are NOT rationally saturated.
- sixth_families.txt: empty; no candidate extends all five old rows.

Audit:
The complete B and C ranges were enumerated in single scans; D,E,F in
4000-presentation batches (last batches shorter). All completed outputs
were checked for count consistency and equality with their audit output.
fixed_CCC/batch_audit.json contains 84 complete range records, with exact
counts, both summaries, and matching SHA-256 hashes. Duplicate batch data
and duplicate audit lists are represented by these digests. The full
merged primary lists are retained. The reproduction driver uses uniform
4000-presentation chunks for all profiles; its merged lists are required
to reproduce the delivered hashes.

The graph audit explicitly updates components instead of using parent
links. The two fixed-core necessary norm filters use primes 2521 and
3361. Every modular survivor is subjected to exact cycle equations.
The character audit also reverses the cycle anchor/prime order, and checks
every consistency decision by independent integer diagonal reduction.
Both 118030-line character lists agree byte for byte; both final lists
are empty. audit_hashes.json preserves the agreements.

The independent checker verifies all 859958 two-core records, all 100788
three-core records, all 118030 constrained four-core records and every
seed identity. check_lattice.cpp separately compares incremental Hermite
consistency against diagonal reduction on 30000 deterministic systems,
including equation-order invariance for all 19468 feasible systems.

No incomplete exploratory scan is used in this proof package. A partial
fourth-row pilot helped discover the five-row formula; its output is not
needed for either the explicit identity or the exhaustive exclusion.

Generic inequivalence (Proposition 12.21):
For a,b,c,ab/c,b/c outside mu60, u and v have distinct unique pentagon
supports. Hence G has no common pentagon, whereas every member of the
earlier four-parameter family has one. This invariant proves inequivalence
on an explicit open dense set. verify_separation.py checks the finite root
and character data in this analytic argument. Exceptional intersections
are not classified. The main verify.py invokes this additional check.
